<?php 

	$config["per_page"]  = 12; 
	$config["top_limit"] = 3; 
	$config["new_limit"] = 3; 
	$config["new_time"] = 3600 * 24 * 30;

?>
