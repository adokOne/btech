      <!-- ========== FOOTER ========== -->
      <div id="footer">
         <div class="extra">
            <div class="main-width">
               <div class="wrapper">
                  <div class="footer-menu">
                     <div id="navSupp">
                        <div class="ezpagesFooterCol col1" style="width: 14%">
                           <ul>
                              <li><a href="<?php echo url::base()?>page/prowuwku"><?php echo $lang["prowuwku"]?></a></li>
                           </ul>
                        </div>
                        <div class="ezpagesFooterCol col2" style="width: 14%">
                           <ul>
                              <li><a href="<?php echo url::base()?>page/delivery"><?php echo $lang["delivery_and_pay"]?></a></li>
                           </ul>
                        </div>
                        <div class="ezpagesFooterCol col3" style="width: 14%">
                           <ul>
                              <li><a href="<?php echo url::base()?>page/contact_us"><?php echo $lang["contact_us"]?></a></li>
                           </ul>
                        </div>
                        <br class="clearBoth" />                  
                     </div>
                  </div>
                  <div class="copyright">
                     <!-- ========== COPYRIGHT ========== -->
                     Copyright &copy; 2014 <a href="<?php echo url::base();?>" target="_blank"><?php echo Kohana::config("core.site_name")?></a>. Powered by <a href="http://vk.com/adok_one" target="_blank">Adok</a>
                     <!-- =============================== -->
                  </div>
                  <div>
                     <!-- {%FOOTER_LINK} -->
                  </div>
                  <!--<div class="cards">
                     <img src="includes/templates/template_default/images/paypal.gif" alt="" />    </div>-->
                  <div class="back_to_top">
                     <a href="#"><span>&uarr;</span> TOP</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- ============================ --> 
      <!--bof- parse time display -->
      <!--eof- parse time display --> 
      <!-- BOF- BANNER #6 display -->
      <!-- EOF- BANNER #6 display --> 
      <!-- ========== IMAGE BORDER BOTTOM ========== --> 
      <!-- ========================================= -->
      <script type="text/javascript">/* CloudFlare analytics upgrade */</script>
   </body>
</html>