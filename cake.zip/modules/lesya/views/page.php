<?php include Kohana::find_file("views","header");?>
<div class="content">
   <div class="extra">
      <div class="main-width">
<h1 id="gvFaqDefaultHeading"><?php echo $page->name()?></h1>
                          <div class="tie3 text2 tie-margin1">
                             <div class="tie3-indent">
                                <div class="wrapper">
                                   <div class="fleft" id="indexProductListCatDescription">
                                   </div>
                                   <div class="content_desc"><?php echo $page->text()?></div>
                                </div>
                             </div>
                          </div>
 </div>
 </div>
 </div>
<?php include Kohana::find_file("views","footer");?>