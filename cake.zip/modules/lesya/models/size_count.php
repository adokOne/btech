<?php


class Size_Count_Model  extends ORM{
	protected $belongs_to = array("good","size");



}