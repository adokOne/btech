<?php


class Feedback_Model  extends ORM{
  
}