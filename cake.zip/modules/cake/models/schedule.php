<?php


class Schedule_Model  extends ORM{
	protected $has_many = array("goods");

	public function day_num(){

	}

	public function hours(){
		
	}
}