<table>
	<tr>
		<td colspan="2">
			Для вас був  згенерований новий пароль, дані облікового запису:
		</td>
	</tr>
	<tr>
		<td>Ім'я</td><td><?php echo $name?></td>
	</tr>
	<tr>
		<td>Пошта</td><td><?php echo $email?></td>
	</tr>
	<tr>
		<td>Пароль</td><td><?php echo $password?></td>
	</tr>
</table>