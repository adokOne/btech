<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'username'	  =>	'Логин',
	'email'	      =>	'Email',
	'last_login'  =>	'Последний вход',
	'logins'	  =>	'Колличество входов',
	'active'	  =>	'Активный?',
);