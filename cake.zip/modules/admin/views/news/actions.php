	<div class="col-xs-12 col-sm-5 col-md-5 col-lg-8">
		<ul id="sparks" class="">
			<li class="sparks-info">
				<a class="btn btn-primary" href="/admin/news/new_one">Добавить</a>
			</li>
		</ul>
	</div>