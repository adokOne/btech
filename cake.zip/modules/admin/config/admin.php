<?php defined('SYSPATH') OR die('No direct access allowed.');

	$config['admin_type'] = 'ext';
	$config['per_page']   = 6;

?>