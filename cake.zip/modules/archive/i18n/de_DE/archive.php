<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'directory_unwritable' => 'Das Verzeichnis %s, in dem die Datei gespeichert werden soll, ist nicht beschreibbar. Korrigieren Sie bitte die Zugriffsrechte und versuchen Sie es erneut.',
	'filename_conflict'    => 'Der für das Archiv gewählte Dateiname %s existiert bereits und ist nicht beschreibbar. Löschen Sie bitte diese Datei und versuchen Sie es erneut.'
);