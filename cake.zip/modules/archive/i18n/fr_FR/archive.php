<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'directory_unwritable' => 'Le répertoire spécifié %s pour la sauvegarde du fichier n\'est pas accessible en écriture. Veuillez corriger les permissions puis réessayer.',
	'filename_conflict'    => 'L\'archive %s demandée existe déjà et n\'est pas accessible en écriture. Veuillez supprimer le fichier en conflit puis réessayer.'
);