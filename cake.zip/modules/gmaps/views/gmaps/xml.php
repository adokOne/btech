<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<p><?=$location->title;?>, <br /><?=$location->description;?></p>