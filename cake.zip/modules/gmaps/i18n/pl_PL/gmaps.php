<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_marker'		=>	'Nieprawidłowe parametry markera (szerokość geograficzna: %s, długość geograficzna: %s)',
	'invalid_dimensions'	=>	'Nieprawidłowe wymiary mapy (szerokość: %s, wysokość: %s)',
);
