<?php defined('SYSPATH') OR die('No direct access allowed.');

$config['allowed_filetypes'] = array
(
	'gif',
	'jpg', 'jpeg',
	'png',
	'tif', 'tiff',
	'swf',
	'htm', 'html',
	'css',
	'js',
	'tpl'
);
