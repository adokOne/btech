<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<h2>Smarty is disabled!</h2>
<p><?php echo $message; ?></p>
