<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'required'                 => 'Alguns campos necessários não foram prenchidos: %s',
	'gateway_connection_error' => 'Um erro aconteceu ao conectar ao gateway de pagamento. Por favor conatte o webmaster se o problema persistir.',
	'invalid_certificate'      => 'O arquivo de certificado é inválido: %s',
	'no_dlib'                  => 'Não foi possível carregar a biblioteca dinâmica: %s',
	'error'                    => 'Houve um erro ao processar a transação: %s',
);