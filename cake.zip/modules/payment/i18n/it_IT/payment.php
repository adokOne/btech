<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'required'                 => 'Alcuni campi obbligatori non sono stati forniti: %s',
	'gateway_connection_error' => 'Si è verificato un errore durante la connessione alla piattaforma di pagamento. Se il problema persiste contattare l\'amministratore del sito.',
	'invalid_certificate'      => 'Certificato non valido: %s',
	'no_dlib'                  => 'Impossibile caricare la libreria dinamica: %s',
	'error'                    => 'Si è verificato un errore durante la transazione: %s',
);