<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'required'                 => 'Des champs obligatoires n\'ont pas été remplis: %s',
	'gateway_connection_error' => 'Une erreur de connexion à la plateforme de paiement est survenue. Veuillez contacter le Webmaster si le problème persiste.',
	'invalid_certificate'      => 'Le fichier de certificats suivant est invalide: %s',
	'no_dlib'                  => 'Impossible de charger la librairie dynamique suivante: %s',
	'error'                    => 'Une erreur s\'est produite lors de la transaction suivante: %s',
);
