<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'      => 'Il gruppo %s non è stato definito in configurazione.',
	'extension_not_loaded' => 'L\'estensione di PHP %s deve essere caricata per poter usare questo driver.',
	'unwritable'           => 'La cartella di deposito, <tt>%s</tt>, non ha i permessi in scrittura.',
	'resources'            => 'Risorsa non serializzabile. Impossibile immagazzinare.',
	'driver_error'         => '%s',
);