<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang['query_methods_not_allowed'] = 'Non è consentito l\'uso dei metodi di Query mediante ORM.';
