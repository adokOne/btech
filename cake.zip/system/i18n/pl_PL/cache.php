<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'      => 'Grupa %s nie została zdefiniowana w konfiguracji.',
	'extension_not_loaded' => 'Aby użyć tego sterownika musi zostać załadowane rozszerzenie PHP %s.',
	'unwritable'           => 'Wybrane w konfiguracji miejsce, %s, jest tylko do odczytu.',
	'resources'            => 'Zachowanie danych w pamięci podręcznej jest niemożliwe z powodu braku możliwości serializacji.',
	'driver_error'         => '%s',
);