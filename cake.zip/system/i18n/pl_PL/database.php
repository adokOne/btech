<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'       => 'Brak definicji grupy % w konfiguracji.',
	'error'                 => 'Wystąpił błąd SQL: %s',
	'connection'            => 'Wystąpił błąd podczas połączenia do bazy danych: %s',
	'invalid_dsn'           => 'Ustawiony DSN jest nieprawidłowy: %s',
	'must_use_set'          => 'Proszę ustawić sekcję SET dla zapytania.',
	'must_use_where'        => 'Proszę ustawić sekcję WHERE dla zapytania.',
	'must_use_table'        => 'Proszę wybrać tabelę dla zapytania.',
	'table_not_found'       => 'Tabeli %s nie ma w bazie danych.',
	'not_implemented'       => 'Wywołana metoda, %s, nie jest obsługiwana przez sterownik.',
	'result_read_only'      => 'Wynik zapytania jest tylko do odczytu.'
);