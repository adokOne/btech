<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang['query_methods_not_allowed'] = 'Korzystając z ORM nie można używać zapytań.';
