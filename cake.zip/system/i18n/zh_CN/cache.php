<?php

$lang = array
(
	'undefined_group'      => '配置未定义 %s 组。',
	'extension_not_loaded' => 'PHP %s 扩展必须使用这个驱动加载。',
	'unwritable'           => '配置的储存地址不可写：%s。',
	'resources'            => '资源无法缓存，因为资源没有被序列化。',
	'driver_error'         => '%s',
);