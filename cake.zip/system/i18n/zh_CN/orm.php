<?php

$lang['query_methods_not_allowed'] = 'ORM 的 Query 方法不能使用';