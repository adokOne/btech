<?php

$lang = array
(
	'invalid_subject'  => '尝试加入无效的 subject %s 到 %s 失败：Subjects 必须继承 Event_Subject 类',
	'invalid_observer' => '尝试加入无效的 observer %s 到 %s 失败：Observers 必须继承 Event_Observer 类',
);
