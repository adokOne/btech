<?php

$lang = array
(
	'not_writable' => '上传的目标文件夹似乎没有写入权限：%s。',
);