<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group' => '分页配置中未定义组：%s。',
	'page'     => '页',
	'pages'    => '页',
	'item'     => '条',
	'items'    => '条',
	'of'       => ' / ',
	'first'    => '首页',
	'last'     => '末页',
	'previous' => '前页',
	'next'     => '后页',
);
