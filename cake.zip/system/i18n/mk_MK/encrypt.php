<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'requires_mcrypt'   => 'За користење на библиотеката Encrypt, mcrypt мора да постои.',
	'no_encryption_key' => 'За користење на библиотеката Encrypt, мора да напишете encryption key во config датотеката.'
);
