<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'general_error' => 'Се појави грешка при испраќање на емаил пораката.'
);