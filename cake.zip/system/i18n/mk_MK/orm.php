<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang['method_not_implemented'] = 'Методата %s не е имплементирана во %s ORM моделот.';
