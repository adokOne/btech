<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_subject'  => 'Le sujet %s n\'a pas pu peut être attaché à %s. Les sujets doivent étendre la classe Event_Subject.',
	'invalid_observer' => 'L\'observeur %s n\'a pas pu peut être attaché à %s. Les observeurs doivent étendre la classe Event_Observer.',
);
