<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang['query_methods_not_allowed'] = 'Métodos de consulta não podem ser usados atráves de ORM';