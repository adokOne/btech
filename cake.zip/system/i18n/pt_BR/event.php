<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_subject'  => 'Tentativa de anexar um sujeito inválido %s a %s falhou: Sujeitos devem extender a classe Event_Subject',
	'invalid_observer' => 'Tentativa de anexar um observador inválido %s a %s falhou: Observadores devem extender a classe Event_Observer',
);
