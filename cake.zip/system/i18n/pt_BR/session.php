<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_session_name' => 'O session_name, %s, é inválido. Deve conter apenas caracteres alfanuméricos e ao menos uma letra deve estar presente.',
);