<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'benchmarks'   => 'Benchmarks',
	'post_data'    => 'Dados de Post',
	'no_post'      => 'Não existem dados de Post',
	'session_data' => 'Dados de Sessão',
	'no_session'   => 'Nao existem dados de Sessão',
	'queries'      => 'Consultas ao Banco de Dados',
	'no_queries'   => 'Não existem consultas',
	'no_database'  => 'Banco de dados não foi carregado',
    'cookie_data'  => 'Dados de cookie',
    'no_cookie'    => 'Sem dados de cookie',
);
