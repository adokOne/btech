<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_subject'  => 'Yritys liittää epäkelpo kohde %s -> %s epäonnistui: Kohteiden täytyy laajentaa Event_Subject -luokkaa',
	'invalid_observer' => 'Yritys liittää epäkelpo tarkkailija %s -> %s epäonnistui: Tarkkailijoiden täytyy laajentaa Event_Observer -luokkaa',
);
