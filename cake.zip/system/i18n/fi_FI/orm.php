<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang['query_methods_not_allowed'] = 'Suoria query-kutsuja ei voi käyttää ORM:n kanssa';