<?php defined('SYSPATH') or die('No direct script access.'); ?>

2014-07-15 15:50:13 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, hotel_json/hotel_rooms?user_ip=0.0.0.0&extended_token=3388447564&key=87b95750-9390-4eaf-82a6-b983bc904aca&session_id=53c521e0178c52334f000008&hotel_id=53c521ec178c52334f000044&lang=ru&is_package=1, не найдена. в файле /home/adok/WWW/cake/system/core/Kohana.php, на строке 841
