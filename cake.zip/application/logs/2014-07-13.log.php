<?php defined('SYSPATH') or die('No direct script access.'); ?>

2014-07-13 15:46:24 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, kohana.png, не найдена. в файле /home/adok/WWW/cake/system/core/Kohana.php, на строке 841
