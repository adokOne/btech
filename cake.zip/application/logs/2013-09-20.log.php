<?php defined('SYSPATH') or die('No direct script access.'); ?>

2013-09-20 09:55:22 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, kohana.png, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 10:08:52 +03:00 --- error: Не пойманное Kohana_Exception: Запрошенный вид, not_found, не найден в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 1162
2013-09-20 10:19:04 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, user/logout, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 10:19:54 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, users/logout, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 10:47:09 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Incorrect table name '' - SHOW COLUMNS FROM `` в файле /home/adok/WWW/b_tech/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-09-20 11:40:13 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'id' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `email`, `username`, `logins`, `last_login`
ORDER BY `id` ASC
LIMIT 0, 20 в файле /home/adok/WWW/b_tech/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-09-20 11:59:08 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Unknown column 'id' in 'field list' - SELECT SQL_CALC_FOUND_ROWS `id`, `email`, `username`, `logins`, `last_login`
ORDER BY `id` ASC
LIMIT 0, 20 в файле /home/adok/WWW/b_tech/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-09-20 12:00:28 +03:00 --- error: Не пойманное PHP Error: include(/home/adok/WWW/b_tech/modules/admin/views/ext/constructor/main/base.php): failed to open stream: No such file or directory в файле /home/adok/WWW/b_tech/modules/admin/views/ext/list.php, на строке 3
2013-09-20 12:05:22 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Incorrect table name '' - SHOW COLUMNS FROM `` в файле /home/adok/WWW/b_tech/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-09-20 12:27:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, Employee.js?_dc=1379669260057, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 12:27:40 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, Employee.js?_dc=1379669260907, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 12:27:41 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, Employee.js?_dc=1379669261499, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 12:27:53 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, Employee.js?_dc=1379669273726, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 12:28:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, Employee.js?_dc=1379669282076, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 12:28:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, Employee.js?_dc=1379669282495, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 12:28:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, Employee.js?_dc=1379669282684, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 12:28:02 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, Employee.js?_dc=1379669282932, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 12:28:03 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, Employee.js?_dc=1379669283190, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 13:49:44 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, Employee.js?_dc=1379674184456, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 13:49:45 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, Employee.js?_dc=1379674185262, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 13:49:45 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, Employee.js?_dc=1379674185526, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 15:05:29 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') AS last_login
FROM (`users` AS `daddy`)
ORDER BY `daddy`.`id` ASC
LIMIT 0, 20' at line 1 - SELECT SQL_CALC_FOUND_ROWS `id`, `email`, `username`, `logins`, `active`, CAST((DATE_FORMAT(FROM_UNIXTIME(last_login),GET_FORMAT(DATE,'EUR')))) AS last_login
FROM (`users` AS `daddy`)
ORDER BY `daddy`.`id` ASC
LIMIT 0, 20 в файле /home/adok/WWW/b_tech/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-09-20 15:16:40 +03:00 --- error: Не пойманное PHP Error: trim() expects parameter 1 to be string, array given в файле /home/adok/WWW/b_tech/modules/admin/libraries/Ext_Constructor.php, на строке 80
2013-09-20 15:17:06 +03:00 --- error: Не пойманное PHP Error: trim() expects parameter 1 to be string, object given в файле /home/adok/WWW/b_tech/modules/admin/libraries/Ext_Constructor.php, на строке 80
2013-09-20 16:01:06 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, some/url/to/select/records/from/db?_dc=1379682066565, не найдена. в файле /home/adok/WWW/b_tech/system/core/Kohana.php, на строке 841
2013-09-20 16:03:06 +03:00 --- error: Не пойманное PHP Error: end() expects parameter 1 to be array, null given в файле /home/adok/WWW/b_tech/modules/admin/libraries/Ext_Constructor.php, на строке 71
2013-09-20 16:03:42 +03:00 --- error: Не пойманное PHP Error: end() expects parameter 1 to be array, null given в файле /home/adok/WWW/b_tech/modules/admin/libraries/Ext_Constructor.php, на строке 71
2013-09-20 16:16:19 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''id' AND `1` = 2' at line 1 - DELETE FROM `users` WHERE 0 'id' AND `1` = 2 в файле /home/adok/WWW/b_tech/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-09-20 16:16:46 +03:00 --- error: Не пойманное PHP Error: end() expects parameter 1 to be array, null given в файле /home/adok/WWW/b_tech/modules/admin/libraries/Ext_Constructor.php, на строке 71
2013-09-20 18:02:16 +03:00 --- error: Не пойманное Kohana_Exception: Свойство key не входит в состав класса User_Model. в файле /home/adok/WWW/b_tech/system/libraries/ORM.php, на строке 416
2013-09-20 18:03:58 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Cannot delete or update a parent row: a foreign key constraint fails (`btech`.`roles_users`, CONSTRAINT `fk_users_has_roles_key` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE) - DELETE FROM `users` WHERE `id` = 1 в файле /home/adok/WWW/b_tech/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-09-20 18:04:06 +03:00 --- error: Не пойманное Kohana_Database_Exception: Ошибка SQL: Cannot delete or update a parent row: a foreign key constraint fails (`btech`.`roles_users`, CONSTRAINT `fk_users_has_roles_key` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE) - DELETE FROM `users` WHERE `id` = 1 в файле /home/adok/WWW/b_tech/system/libraries/drivers/Database/Mysql.php, на строке 371
2013-09-20 18:15:36 +03:00 --- error: Не пойманное PHP Error: Argument 1 passed to Auth_User_Model::validate() must be an array, none given, called in /home/adok/WWW/b_tech/modules/auth/models/user.php on line 17 and defined в файле /home/adok/WWW/b_tech/modules/auth/models/auth_user.php, на строке 30
2013-09-20 18:15:51 +03:00 --- error: Не пойманное PHP Error: Argument 1 passed to Auth_User_Model::validate() must be an array, object given, called in /home/adok/WWW/b_tech/modules/auth/models/user.php on line 17 and defined в файле /home/adok/WWW/b_tech/modules/auth/models/auth_user.php, на строке 30
2013-09-20 18:19:44 +03:00 --- error: Не пойманное PHP Error: Argument 1 passed to Auth_User_Model::validate() must be an array, object given, called in /home/adok/WWW/b_tech/modules/auth/models/user.php on line 19 and defined в файле /home/adok/WWW/b_tech/modules/auth/models/auth_user.php, на строке 30
2013-09-20 18:20:37 +03:00 --- error: Не пойманное Kohana_Exception: Свойство key не входит в состав класса User_Model. в файле /home/adok/WWW/b_tech/system/libraries/ORM.php, на строке 364
2013-09-20 18:20:47 +03:00 --- error: Не пойманное PHP Error: Argument 1 passed to Auth_User_Model::validate() must be an array, object given, called in /home/adok/WWW/b_tech/modules/auth/models/user.php on line 20 and defined в файле /home/adok/WWW/b_tech/modules/auth/models/auth_user.php, на строке 30
2013-09-20 18:34:01 +03:00 --- error: Cache: Unable to delete cache file: /home/adok/WWW/b_tech/application/cache/session_r9n73q7psj7n24u8jlfrsjm4e7~Array~1379698430
