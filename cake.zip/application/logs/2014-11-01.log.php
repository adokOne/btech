<?php defined('SYSPATH') or die('No direct script access.'); ?>

2014-11-01 14:36:44 +02:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2014-11-01 14:36:44 +02:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2014-11-01 14:36:44 +02:00 --- error: core.uncaught_exception
2014-11-01 14:36:44 +02:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2014-11-01 14:36:44 +02:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2014-11-01 14:36:44 +02:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2014-11-01 14:36:44 +02:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2014-11-01 14:36:44 +02:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2014-11-01 14:36:44 +02:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2014-11-01 14:36:44 +02:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2014-11-01 14:36:44 +02:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
