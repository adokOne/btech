<?php

$config = array(
	array(
		"url" => "#",
	),
	// array(
	// 	"heading" => "wefew",
	// 	"pre_heading" => "wfewef",
	// 	"desc" => "wefwefwe",
	// 	"link" => "#",
	// ),
	// array(
	// 	"heading" => "wfwefwef ",
	// 	"pre_heading" => "fwe fwefwef",
	// 	"desc" => "wfwefwefwe",
	// 	"link" => "#",
	// ),
);