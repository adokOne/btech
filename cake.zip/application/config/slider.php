<?php

$config = array(
	array(
		"heading" => "Вишивнака ",
		"pre_heading" => "by Lesya",
		"desc" => "Сучасний одяг з українською вишивкою",
		"link" => "#",
	),
	// array(
	// 	"heading" => "wefew",
	// 	"pre_heading" => "wfewef",
	// 	"desc" => "wefwefwe",
	// 	"link" => "#",
	// ),
	// array(
	// 	"heading" => "wfwefwef ",
	// 	"pre_heading" => "fwe fwefwef",
	// 	"desc" => "wfwefwefwe",
	// 	"link" => "#",
	// ),
);